package calculo;

public class Numero {
   private int valor;
   public Numero() {
	   
	   this.valor=0;
   }
   public void setValor(int valor) {
	   this.valor=valor;
   }
   public int getvalor() {
	   return this.valor;
   }
}
