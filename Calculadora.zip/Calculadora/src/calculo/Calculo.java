package calculo;

import java.util.Scanner;

public class Calculo {
	static public void main(String[]args) {
    Scanner scan=new Scanner (System.in);
    
    Numero n1 = new Numero();
    Numero n2 = new Numero();
    Numero res = new Numero();
    String opc="s";
    
    while(opc.equals("s") || opc.equals("s")) {
        System.out.printf("%nDigite valor 1: ");
        n1.setValor(scan.nextInt());
        System.out.printf("%nDigite valor 1: ");
        n2.setValor(scan.nextInt());
        res.setValor(n1.getvalor() + n2.getvalor());
        System.out.printf("%nA soma de %d com %d e igual a %d: ",n1.getvalor(),n2.getvalor(),res.getvalor());
        System.out.printf("%dDeseja somar outro valor (S/N)?");
        opc=scan.next();
        System.out.printf("%n");
    }
    
    
	}
	
    
}
